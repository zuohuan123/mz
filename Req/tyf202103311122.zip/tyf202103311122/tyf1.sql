prompt Importing table lccontili...
set feedback off
set define off
insert into lccontili (TRANSNO, CONTNO, PROPOSALCONTNO, PREM, ACCRATE, ACCNO, BAK1, BAK2, BAK3, BAK4, BAK5, INSURCECOM, RISKCODE, ORDERNUMBER, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('4', '4', '4', 9.92, null, '2', null, null, null, null, null, 'ANZL', '1', null, null, null, null, null);

insert into lccontili (TRANSNO, CONTNO, PROPOSALCONTNO, PREM, ACCRATE, ACCNO, BAK1, BAK2, BAK3, BAK4, BAK5, INSURCECOM, RISKCODE, ORDERNUMBER, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('4', '4', '4', 9.93, null, '3', null, null, null, null, null, 'ANZL', '1', null, null, null, null, null);

insert into lccontili (TRANSNO, CONTNO, PROPOSALCONTNO, PREM, ACCRATE, ACCNO, BAK1, BAK2, BAK3, BAK4, BAK5, INSURCECOM, RISKCODE, ORDERNUMBER, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('4', '4', '4', 9.94, null, '4', null, null, null, null, null, 'ANZL', '1', null, null, null, null, null);

insert into lccontili (TRANSNO, CONTNO, PROPOSALCONTNO, PREM, ACCRATE, ACCNO, BAK1, BAK2, BAK3, BAK4, BAK5, INSURCECOM, RISKCODE, ORDERNUMBER, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('4', '4', '4', 9.95, null, '5', null, null, null, null, null, 'ANZL', '1', null, null, null, null, null);

insert into lccontili (TRANSNO, CONTNO, PROPOSALCONTNO, PREM, ACCRATE, ACCNO, BAK1, BAK2, BAK3, BAK4, BAK5, INSURCECOM, RISKCODE, ORDERNUMBER, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('1', '1', '1', null, null, '1', null, null, null, null, null, null, '1', null, null, null, null, null);

insert into lccontili (TRANSNO, CONTNO, PROPOSALCONTNO, PREM, ACCRATE, ACCNO, BAK1, BAK2, BAK3, BAK4, BAK5, INSURCECOM, RISKCODE, ORDERNUMBER, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('2', '2', '2', null, null, '1', null, null, null, null, null, null, '1', null, null, null, null, null);

insert into lccontili (TRANSNO, CONTNO, PROPOSALCONTNO, PREM, ACCRATE, ACCNO, BAK1, BAK2, BAK3, BAK4, BAK5, INSURCECOM, RISKCODE, ORDERNUMBER, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('3', '3', '3', null, null, '1', null, null, null, null, null, null, '1', null, null, null, null, null);

insert into lccontili (TRANSNO, CONTNO, PROPOSALCONTNO, PREM, ACCRATE, ACCNO, BAK1, BAK2, BAK3, BAK4, BAK5, INSURCECOM, RISKCODE, ORDERNUMBER, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('4', '4', '4', null, null, '1', null, null, null, null, null, 'ANZL', '1', null, null, null, null, null);

insert into lccontili (TRANSNO, CONTNO, PROPOSALCONTNO, PREM, ACCRATE, ACCNO, BAK1, BAK2, BAK3, BAK4, BAK5, INSURCECOM, RISKCODE, ORDERNUMBER, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('5', '5', '5', null, null, '1', null, null, null, null, null, null, '1', null, null, null, null, null);

insert into lccontili (TRANSNO, CONTNO, PROPOSALCONTNO, PREM, ACCRATE, ACCNO, BAK1, BAK2, BAK3, BAK4, BAK5, INSURCECOM, RISKCODE, ORDERNUMBER, MAKEDATE, MAKETIME, MODIFYDATE, MODIFYTIME)
values ('6', '6', '6', null, null, '1', null, null, null, null, null, null, '1', null, null, null, null, null);

prompt Done.
