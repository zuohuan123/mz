$(function(){
	
	
	//加载当前登录的人
	$.ajax({
		url :  path+ "/loginUserController/getUserInfo.do",
		type : "POST",
		dataType : "json",
		success : function(data) {
			if(data == null){
				alert("当前登录session已经过期！");
			}
			$("#operator").val(data.emplID);
		},
		error : function() {
			alert("加载当前登录者失败!");
		}
	});
	
	
	//加载单证号段状态
	$.ajax({
		url:path + "/certifySectionAddController/selectCertiStatus.do",// 后台请求URL地址
		type : "POST",
		dataType : "json",
		success : function(data) {
			//console.log(data);
			for(var i =0;i<data.length;i++){
				 $('#certifyStatus').append
				 ("<option value=" + data[i].code + ">" +
						 data[i].codeName + "</option>");
			}
		},
		error : function() {
			alert("加载单证号段状态失败");
		}
	});
	
	//加载单证号段渠道标记
	$.ajax({
		url:path + "/certifySectionAddController/selectCertiChannel.do",// 后台请求URL地址
		type : "POST",
		dataType : "json",
		success : function(data) {
			//console.log(data);
			for(var i =0;i<data.length;i++){
				 $('#channelMarking').append
				 ("<option value=" + data[i].code + ">" +
						 data[i].codeName + "</option>");
			}
		},
		error : function() {
			alert("加载单证号段渠道标记失败");
		}
	});
	
	//加载input的数据
	$.ajax({
		url : path + "/certifySectionModifyController/certifySectionModifySaveSelect.do",
		data:{"id":id},
		type: "post",
		dataType:"json",
		success:function(data){
			$("#insuranceCompany").val(data.name);
			$("#certifyType").val(data.codeName);
			$("#certifyStart").val(data.certifyStart);
			$("#certifyEnd").val(data.certifyEnd);
			$('#certifyStatus').select2("val",data.certifyStatus);
			if(data.bak1==null){
				$("#channelMarking").select2("val","BH");
			}else{
				$("#channelMarking").select2("val",data.bak1);
			}
		},
		error:function(){
			alert("数据加载失败!!!");
		}
	});
	

	
	
	//单证号段修改提交
	$("#save").click(function(){
		if($("#certifyStatus").val().trim()=='' || $("#certifyStatus").val().trim()==null){
			alert("请选择单证号段状态!");
			return;
		}
		var data = $("#form-plus").serialize();
		if (!confirm("确定要修改该单证信息吗?")) {
			alert('您已取消该修改操作!');
			return;
		}
//		console.log(data + '&id='+id);
		$.ajax({
			url : path + "/certifySectionModifyController/certifySectionModifyMiddle_MainSave.do",
			data:data + '&id='+id,
			type: "post",
			dataType:"json",
			success:function(data){
				if(data.success==true){
					alert(data.msg);
					window.location.href="CertifySectionModifySelect.jsp";
				}else{
					alert(data.msg);
				}
			},
			error:function(){
				alert("提交失败!!!");
			}
		});
		
	});
	
	
});
