

var selectedInsCom = '请选择';
var selectedCertiStatus = '请选择';
var selectedCity = '请选择';
$(function(){
	
	//加载当前登录的人
	$.ajax({
		url :  path+ "/loginUserController/getUserInfo.do",
		type : "POST",
		dataType : "json",
		success : function(data) {
			if(data == null){
				alert("当前登录session已经过期！");
			}
			$("#operator").val(data.emplID);
		},
		error : function() {
			alert("加载当前登录者失败!");
		}
	});
	
	
	//加载单证号段状态
	$.ajax({
		url:path + "/certifySectionAddController/selectCertiStatus.do",// 后台请求URL地址
		type : "POST",
		dataType : "json",
		success : function(data) {
			//console.log(data);
			for(var i =0;i<data.length;i++){
				 $('#certifyStatus').append
				 ("<option value=" + data[i].code + ">" +
						 data[i].codeName + "</option>");
			}
		},
		error : function() {
			alert("加载单证号段状态失败");
		}
	});
	
	
	//加载保险公司
	$.ajax({
		url:path + "/certifySectionAddController/selectIncuranceCompanyAdd.do",// 后台请求URL地址
		type : "POST",
		dataType : "json",
		success : function(data) {
			//console.log(data);
			for(var i =0;i<data.length;i++){
				//console.log(data[i].agentcom);
				//console.log(data[i].name);
				 $('#insuranceCompany').append
				 ("<option value=" + data[i].agentcom + ">" +
						 data[i].name + "</option>");
			}
		},
		error : function() {
			alert("加载保险公司失败");
		}
	});
	
	
	// 加载city
	$.ajax({
		url : path + "/bankInstitutionAddController/loadCities.do",
		type : "POST",
		dataType : "json",
		success : function(data) {
			for (var i = 0; i < data.length; i++) {
				$("#city").append(
						"<option value=" + data[i].cityCode + ">"
								+ data[i].cityName + "</option>");
			}
		},
		error : function() {
			alert("加载城市失败!");
		}
	});
	//加载单证号段渠道标记
	$.ajax({
		url:path + "/certifySectionAddController/selectCertiChannel.do",// 后台请求URL地址
		type : "POST",
		dataType : "json",
		success : function(data) {
			//console.log(data);
			for(var i =0;i<data.length;i++){
				 $('#channelMarking').append
				 ("<option value=" + data[i].code + ">" +
						 data[i].codeName + "</option>");
			}
		},
		error : function() {
			alert("加载单证号段渠道标记失败");
		}
	});
	//加载表单的数据
	$.ajax({
		url : path + "/certifySectionModifyController/certifySectionModifySaveSelect.do",
		data:{"id":id},
		type: "post",
		dataType:"json",
		success:function(data){
			$('#insuranceCompany').select2("val",data.agentcom);
			$("#certifyType").val(data.codeName);
			$("#certifyStart").val(data.certifyStart);
			$("#certifyEnd").val(data.certifyEnd);
			$("#city").select2("val",data.city);
			selectedCity = data.city;
			$('#certifyStatus').select2("val",data.certifyStatus);
			if(data.bak1==null){
				$("#channelMarking").select2("val","BH");
			}else{
				$("#channelMarking").select2("val",data.bak1);
			}
		},
		error:function(){
			alert("数据加载失败!!!");
		}
	});
	
	$("#city").change(function() {
		selectedCity = ($(this).children('option:selected').val().trim());
		$("#city").val(selectedCity);
		alert($("#city").val());
		// alert("公司： "+ selectedInsCom);
		// loadCertiName(selectedInsCom,selectedCertiType);
	});
	
	$("#save").click(function(){
		
		
		var datas = new Object();
		if($("#operator").val().trim()==''){
			alert("您已经超时登录!");
			return;
		}
		if($("#insuranceCompany").val().trim()=='' || $("#insuranceCompany").val().trim()=='请选择'){
			alert("请选择保险公司");
			return;
		}
		if($("#certifyStatus").val().trim()=='' || $("#certifyStatus").val().trim()== '请选择'){
			alert("请选择单证状态");
			return;
		}
		
  	  
  		var reg = /^[a-zA-Z0-9]+$/;
  		var certifyNumStartE = $("#certifyStart").val().trim();
  		if(certifyNumStartE==''){
			alert("单证开始号码不能为空!");
			return;
		}
  		if(reg.test(certifyNumStartE)){
  			certifyNumStartE = certifyNumStartE.replace( /[a-zA-Z]/g,"").trim();
  		}else{
  			alert("单证开始号码输入有误!");
  			return;
  		}  
  		
  		var certifyNumEndE = $("#certifyEnd").val().trim();
  		if(certifyNumEndE==''){
			alert("单证结束号码不能为空!");
			return;
		}
  		if(reg.test(certifyNumEndE)){
  			certifyNumEndE = certifyNumEndE.replace(/[a-zA-Z]/g,"").trim();
  		}else{
  			alert("单证结束号码输入有误!");
  			return;
  		}
  	  
		datas.certifystart = parseInt(certifyNumStartE);
		datas.certifyend = parseInt(certifyNumEndE);
		if(datas.certifystart>=datas.certifyend){
			alert("单证号段开始号码不能大于等于单证号段结束号码");
			return;
		}
//		datas.operator = $("#operator").val().trim();
//		datas.insuranceCompany = $("#insuranceCompany").val().trim();
//		datas.certifyStatus = $("#certifyStatus").val().trim();
//		datas.id = id;
		
		var data = $("#form-plus").serialize();
		if (!confirm("确定要修改该单证信息吗?")) {
			alert('您已取消该修改操作!');
			return;
		}
		
		//提交
		$.ajax({
			url : path + "/certifySectionModifyController/certifySectionModifySaveMiddle.do",
//			url : path + "/certifySectionModifyController/certifySectionModifySave.do",
			
			data: data +'&id='+id,
			type: "post",
			dataType:"json",
			success:function(data){
				if(data.success==true){
					alert(data.msg);
					window.location.href="CertifySectionModifySelect.jsp";
				}else{
					alert(data.msg);
				}
			},
			error:function(){
				alert("提交失败!!!");
			}
		});
		
	});
	
	
//	  $('form').bootstrapValidator({
//          message: 'This value is not valid',
//          feedbackIcons: {
//              valid: 'glyphicon glyphicon-ok',
//              invalid: 'glyphicon glyphicon-remove',
//              validating: 'glyphicon glyphicon-refresh'
//          },
//          fields: {
//        	  operator:{
//                  validators: {
//                        notEmpty: {
//                            message: '操作员不能为空'
//                        }
//                    }
//               },
//               certifyStart: {
//                  validators: {
//                      notEmpty: {
//                          message: '单证起始号码不能为空'
//                      },
//                      regexp: {
//                          regexp: /^[0-9a-zA-Z]+$/,
//                          message: '只能由数字和字母组成'
//                      } 
//                  }
//              },
//             
//              certifyEnd:{
//                validators: {
//                      notEmpty: {
//                          message: '单证起始终止不能为空'
//                      },
//                      regexp: {
//                          regexp: /^[0-9a-zA-Z]+$/,
//                          message: '只能由数字和字母组成'
//                      }
//                  }
//               },
//             
//               certifyStatus:{
//                   validators: {
//                         notEmpty: {
//                             message: '单证号段状态不能为空'
//                         }
//                     }
//                },
//                
//                insuranceCompany:{
//                    validators: {
//                          notEmpty: {
//                              message: '保险公司不能为空'
//                          }
//                      }
//                 },
//               
//          },
//          
//          
//          
//          
//         
//          submitHandler: function (validator, form, submitButton) {
//        	  
//        	  	var datas = new Object();
//        	  
//        		var reg = /^[a-zA-Z0-9]+$/;
//        		
//        		var certifyNumStartE = $("#certifyStart").val().trim();
//        		if(reg.test(certifyNumStartE)){
//        			certifyNumStartE = certifyNumStartE.replace( /[a-zA-Z]/g,"").trim();
//        		}else{
//        			alert("单证开始号码输入有误!");
//        			return;
//        		}  
//        		
//        		var certifyNumEndE = $("#certifyEnd").val().trim();
//        		if(reg.test(certifyNumEndE)){
//        			certifyNumEndE = certifyNumEndE.replace(/[a-zA-Z]/g,"").trim();
//        		}else{
//        			alert("单证结束号码输入有误!");
//        			return;
//        		}
//        	  
//    		datas.certifystart = parseInt(certifyNumStartE);
//    		datas.certifyend = parseInt(certifyNumEndE);
//    		if(datas.certifystart>=datas.certifyend){
//				alert("单证号段开始号码不能大于等于单证号段结束号码");
//				return;
//			}
////    		datas.operator = $("#operator").val().trim();
////    		datas.insuranceCompany = $("#insuranceCompany").val().trim();
////    		datas.certifyStatus = $("#certifyStatus").val().trim();
////    		datas.id = id;
//    		
//    		var data = $("#form-plus").serialize();
//    		if (!confirm("确定要修改该单证信息吗?")) {
//    			alert('您已取消该修改操作!');
//    			return;
//    		}
//    		
//    		//提交
//    		$.ajax({
//    			url : path + "/certifySectionModifyController/certifySectionModifySaveMiddle.do",
////    			url : path + "/certifySectionModifyController/certifySectionModifySave.do",
//    			
//    			data: data +'&id='+id,
//    			type: "post",
//    			dataType:"json",
//    			success:function(data){
//    				if(data.success==true){
//    					alert(data.msg);
//    					window.location.href="CertifySectionModifySelect.jsp";
//    				}else{
//    					alert(data.msg);
//    				}
//    			},
//    			error:function(){
//    				alert("提交失败!!!");
//    			}
//    		});
//    		
//    		
//    		
//        	  
//          }
//      });
	
	
	
});