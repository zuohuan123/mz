var selectedInsCom = '请选择';
var selectedCertiType = '请选择';
var selectedCertiName = '请选择';
var selectedCertiStatus = '请选择';
var selectedCertiChannel = '请选择';
$(function() {

	// 加载保险公司
	$.ajax({
		url : path
				+ "/certifySectionAddController/selectIncuranceCompanyAdd.do",// 后台请求URL地址
		type : "POST",
		dataType : "json",
		success : function(data) {
			// console.log(data);
			for (var i = 0; i < data.length; i++) {
				// console.log(data[i].agentcom);
				// console.log(data[i].name);
				$('#insuranceCompany.selectpicker').append(
						"<option value=" + data[i].agentcom + ">"
								+ data[i].name + "</option>");
			}
		},
		error : function() {
			alert("加载保险公司失败");
		}
	});

	// 加载单证号段状态
	$.ajax({
		url : path + "/certifySectionAddController/selectCertiStatus.do",// 后台请求URL地址
		type : "POST",
		dataType : "json",
		success : function(data) {
			// console.log(data);
			for (var i = 0; i < data.length; i++) {
				// console.log(data[i].code);
				// console.log(data[i].codeName);
				$('#certifyStatus.selectpicker').append(
						"<option value=" + data[i].code + ">"
								+ data[i].codeName + "</option>");
			}
		},
		error : function() {
			alert("加载单证状态失败");
		}
	});

	// 加载city
	$.ajax({
		url : path + "/bankInstitutionAddController/loadCities.do",
		type : "POST",
		dataType : "json",
		success : function(data) {
			for (var i = 0; i < data.length; i++) {
				$("#bankCity").append(
						"<option value=" + data[i].cityCode + ">"
								+ data[i].cityName + "</option>");
			}
		},
		error : function() {
			alert("加载城市失败!");
		}
	});

	// 加载渠道标记
	$.ajax({
		url : path + "/certifySectionAddController/selectCertiChannel.do",// 后台请求URL地址
		type : "POST",
		dataType : "json",
		success : function(data) {
			for (var i = 0; i < data.length; i++) {
				$("#channelMarking").append(
						"<option value=" + data[i].code + ">"
								+ data[i].codeName + "</option>");
			}
		},
		error : function() {
			alert("加载渠道标记失败!");
		}
	});

	$("#insuranceCompany").change(function() {
		selectedInsCom = ($(this).children('option:selected').val().trim());
		// alert("公司： "+ selectedInsCom);
		// loadCertiName(selectedInsCom,selectedCertiType);
	});

	$("#certifyType").change(function() {
		selectedCertiType = ($(this).children('option:selected').val().trim());
		// alert("类型： "+selectedCertiType);
		// loadCertiName(selectedInsCom,selectedCertiType);
	});

	// $("#certifyName").change(function(){
	// selectedCertiName = ($(this).children('option:selected').val().trim());
	// alert("名称： "+selectedCertiName);
	// });

	$("#certifyStatus").change(
			function() {
				selectedCertiStatus = ($(this).children('option:selected')
						.val().trim());
				// alert("状态： "+selectedCertiStatus);
			});
	$("#channelMarking").change(
			function() {
				selectedCertiChannel = ($(this).children('option:selected')
						.val().trim());
				// alert("状态： "+selectedCertiStatus);
			});
//	$('form').bootstrapValidator(
//			{
//				message : 'This value is not valid',
//				feedbackIcons : {
//					valid : 'glyphicon glyphicon-ok',
//					invalid : 'glyphicon glyphicon-remove',
//					validating : 'glyphicon glyphicon-refresh'
//				},
//				fields : {
//					operator : {
//						validators : {
//							notEmpty : {
//								message : '操作员不能为空'
//							}
//						}
//					},
//					certifyNumStart : {
//						validators : {
//							notEmpty : {
//								message : '单证起始号码不能为空'
//							},
//							regexp : {
//								regexp : /^[0-9a-zA-Z]+$/,
//
//								message : '只能由数字和字母组成'
//							},
//
//						}
//					},
//
//					certifyNumEnd : {
//						validators : {
//							notEmpty : {
//								message : '单证起始终止不能为空'
//							},
//							regexp : {
//								regexp : /^[0-9a-zA-Z]+$/,
//								message : '只能由数字和字母组成'
//							}
//						}
//					},
//
//					certifyStatus : {
//						validators : {
//							notEmpty : {
//								message : '单证号段状态不能为空'
//							}
//						}
//					},
//
//					insuranceCompany : {
//						validators : {
//							notEmpty : {
//								message : '保险公司不能为空'
//							}
//						}
//					},
//
//				},
//
////				submitHandler : function(validator, form, submitButton) {
////
////					var data = new Object();
////					data.agentcom = selectedInsCom;
////					data.certifystatus = selectedCertiStatus;
////					data.operator = $("#operator").val().trim();
////
////					var reg1 = /^[0-9]+$/;
////					var reg = /^[a-zA-Z]+[0-9]+$/;
////
////					var certifyNumStartE = $("#certifyNumStart").val().trim();
////					if (reg.test(certifyNumStartE)) {
////						certifyNumStartE = certifyNumStartE.replace(
////								/[a-zA-Z]/g, "").trim();
////					} else if (reg1.test(certifyNumStartE)) {
////
////					} else {
////						alert("单证开始号码输入有误!");
////						return;
////					}
////
////					var certifyNumEndE = $("#certifyNumEnd").val().trim();
////					if (reg.test(certifyNumEndE)) {
////						certifyNumEndE = certifyNumEndE
////								.replace(/[a-zA-Z]/g, "").trim();
////					} else if (reg1.test(certifyNumEndE)) {
////
////					} else {
////						alert("单证结束号码输入有误!");
////						return;
////					}
////					// data.certifystart =
////					// parseInt($("#certifyNumStart").val().trim());
////					data.certifystart = parseInt(certifyNumStartE);
////					// data.certifyend =
////					// parseInt($("#certifyNumEnd").val().trim());
////					data.certifyend = parseInt(certifyNumEndE);
////					data.city = $("#bankCity").val().trim();
////					// console.log(data.certifystart);
////					// console.log(data.certifyend);
////
////					if (data.certifystart >= data.certifyend) {
////						alert("单证号段开始号码不能大于等于单证号段结束号码");
////						return;
////					}
////					data.certifystart = $("#certifyNumStart").val().trim()
////							.toUpperCase();
////					data.certifyend = $("#certifyNumEnd").val().trim()
////							.toUpperCase();
////					saveCertifysection(data);
////
////				}
//			});

	// $("#certifyNumEnd").blur(function(){
	//		  
	// var certifyNumStartE = $("#certifyNumStart").val();
	// // alert("**"+certifyNumStartE);
	// var certifyNumEndE = $("#certifyNumEnd").val();
	// // alert("**"+certifyNumEndE);
	// if(certifyNumStartE != "" && certifyNumEndE != ""){
	// var s = parseInt($("#certifyNumStart").val().trim());
	// var e = parseInt($("#certifyNumEnd").val().trim());
	// if(s >= e){
	// $('#forms').data('bootstrapValidator')
	// .updateStatus('certifyNumEnd','NOT_VALIDATED',null)
	// .validateField('certifyNumEnd');
	// }
	// }
	//		 
	//		 
	// });

	$("#save").click(function() {

				var data = new Object();
				data.agentcom = selectedInsCom;
				data.certifystatus = selectedCertiStatus;
				data.bak1 = selectedCertiChannel;
				data.operator = $("#operator").val().trim();

				
				if(data.agentcom == '请选择'){
					alert("请选择保险公司");
					return;
				} 


				if(data.certifystatus == '请选择'){
					alert("请选择单证状态");
					return;
				}
				if(data.bak1 == '请选择'){
					alert("请选择渠道标记");
					return;
				}else if(data.bak1 == 'BH'){
					data.bak1 ="";
				}
				var reg1 = /^[0-9]+$/;
				var reg = /^[a-zA-Z]+[0-9]+$/;

				var certifyNumStartE = $("#certifyNumStart").val().trim();
				if(certifyNumStartE==''){
					alert("单证开始号码不能为空!");
					return;
				}
				if (reg.test(certifyNumStartE)) {
					certifyNumStartE = certifyNumStartE.replace(/[a-zA-Z]/g, "").trim();
				} else if (reg1.test(certifyNumStartE)) {

				} else {
					alert("单证开始号码输入有误!");
					return;
				}

				var certifyNumEndE = $("#certifyNumEnd").val().trim();
				if(certifyNumEndE==''){
					alert("单证结束号码不能为空!");
					return;
				}
				if (reg.test(certifyNumEndE)) {
					certifyNumEndE = certifyNumEndE.replace(/[a-zA-Z]/g, "")
							.trim();
				} else if (reg1.test(certifyNumEndE)) {
						
				} else {
					alert("单证结束号码输入有误!");
					return;
				}
				
				
				
				// data.certifystart =
				// parseInt($("#certifyNumStart").val().trim());
				data.certifystart = parseInt(certifyNumStartE);
				// data.certifyend = parseInt($("#certifyNumEnd").val().trim());
				data.certifyend = parseInt(certifyNumEndE);
				data.city = $("#bankCity").val().trim();
				// console.log(data.certifystart);
				// console.log(data.certifyend);

                if("INSH"==data.agentcom && data.city == ''){
                    alert("请选择城市!");
                    return;
                }

				if (data.certifystart >= data.certifyend) {
					alert("单证号段开始号码不能大于等于单证号段结束号码");
					return;
				}
				data.certifystart = $("#certifyNumStart").val().trim()
						.toUpperCase();
				data.certifyend = $("#certifyNumEnd").val().trim()
						.toUpperCase();
				saveCertifysection(data);

			});
});

// 提交新增的单证号段信息
function saveCertifysection(data) {
	// console.log(data);
	$.ajax({
		url : path + "/certifySectionAddController/add.do",// 后台请求URL地址
		type : "POST",
		dataType : "json",
		data : data,
		success : function(data) {
			if (data.success == true) {
				alert("提交成功");
				window.location.href = "CertifySectionAdd.jsp";
			} else {
				alert(data.msg);
			}

		},
		error : function() {
			alert("提交失败");
		}
	});
};

// 动态加载单证名称的下拉选
// function loadCertiName(selectedInsCom,selectedCertiType){
// var data = new Object();
// data.selectedInsCom = selectedInsCom;
// data.selectedCertiType = selectedCertiType;
// var flag = false;
// if(data.selectedInsCom != '请选择' && data.selectedCertiType != '请选择'){
// flag = true;
// }
// if(flag){
// $.ajax({
// url:path + "/certifySectionAddController/selectCertiNameAdd.do",// 后台请求URL地址
// type : "POST",
// dataType : "json",
// data: data,
// success : function(data) {
// if(data.length == 0){
// selectedCertiName = '请选择';
// }
// $("#certifyName").find("option").remove();
//				
// $('#certifyName.selectpicker').append("<option>请选择</option>")
// for(var i =0;i<data.length;i++){
// // console.log(data[i].certifyCode);
// // console.log(data[i].certifyName);
// $('#certifyName').append
// ("<option value=" + data[i].certifyCode + ">" +
// data[i].certifyName + "</option>");
// }
// $('#certifyName').select2("val","请选择");
// },
// error : function() {
// alert("加载单证名称失败");
// }
// });
// }
//
//
// };

