/**
 * 
 * @param noticeid
 * @param type
 *            1主被保險人 2附屬
 */
function hiddenNoticeELements(topvue, noticeid, type,noticeinfoType) {

	if(!noticeinfoType){
		noticeinfoType="i";
	}
	
	var insuquestion ="insuquestion";
	if(noticeinfoType=="q"){
		
		insuquestion="noticeInfo";
	}
	
	if(noticeinfoType=="a"){
		
		insuquestion="appntquestion";
	}
	
	var questionID = noticeid + noticeinfoType + type;
	try {
		// topvue.form_elementsBYID.commonFormNotice[noticeid].insuquestion[questionID].elementstatus="02";
		if (topvue.form_elementsBYID.commonFormNotice[noticeid][insuquestion][questionID].elementstatus == "02") {
			console.info(noticeid + " 该条告知配置不显示不作处理");

		} else {
				
				topvue.$set( topvue.form_elementsBYID.commonFormNotice[noticeid][insuquestion][questionID],
						"elementstatus", "04");
				
			
		}

	} catch (e) {
		console.info(" error : 告知：" + noticeid + " 所属子元素节点ID配置未找到被保人问题，"
				+ " 请检查告知formelement 的告知配置项 请按照约定进行ID设置 " + noticeid + noticeinfoType
				+ type + " exception:" + e);
	}

	// topvue

}

function showNoticeELements(topvue, noticeid, type ,noticeinfoType) {
	if(!noticeinfoType){
		noticeinfoType="i";
	}
	var questionID = noticeid + noticeinfoType + type;
	var insuquestion ="insuquestion";
	if(noticeinfoType=="q"){
		
		insuquestion="noticeInfo";
	}
	if(noticeinfoType=="n"){
		
		insuquestion="notice";
	}
	try {
		if (topvue.form_elementsBYID.commonFormNotice[noticeid][insuquestion][questionID].elementstatus == "02") {
			console.info(noticeid + " 该条告知配置不显示不作处理");

		} else {
			
				topvue.$set(topvue.form_elementsBYID.commonFormNotice[noticeid][insuquestion][questionID],
						"elementstatus", "01");
			
		}
		// topvue.form_elementsBYID.commonFormNotice[noticeid].insuquestion[questionID].elementstatus="02";
	
	} catch (e) {
		console.info(" error : 告知：" + noticeid + " 所属子元素节点ID配置未找到被保人问题，"
				+ " 请检查告知formelement 的告知配置项 请按照约定进行ID设置 " + noticeid + noticeinfoType
				+ type + " exception:" + e);
	}

	// topvue

}


function showFather(topvue,noticeid){
	if (topvue.form_elementsBYID.commonFormNotice[noticeid].elementstatus == "02") {
		console.info(noticeid + " 该条告知配置不显示不作处理");

	} else {
//		topvue.form_elementsBYID.commonFormNotice[noticeid].elementstatus  = "04";
		topvue.$set(topvue.form_elementsBYID.commonFormNotice[noticeid],
				"elementstatus", "01");
	}
	
}

function hiddenFather(topvue,noticeid){
	
	if ( topvue.form_elementsBYID.commonFormNotice[noticeid].elementstatus == "02") {
		console.info(noticeid + " 该条告知配置不显示不作处理");

	} else {
		topvue.$set(topvue.form_elementsBYID.commonFormNotice[noticeid],
				"elementstatus", "04");
	}
}
//隐藏小于12岁告知
function hiddenAllinfant(topvue,noticeid){
	hiddenFather(topvue, "notice11");
	hiddenFather(topvue, "notice12");
    hiddenFather(topvue, "notice13");
	hiddenNoticeELements(topvue, "notice12", "1", "i");
    hiddenNoticeELements(topvue, "notice13", "1", "i");

}

//显示小于12岁告知
function showAllinfant(topvue){	
	showFather(topvue,"notice11");
	showFather(topvue,"notice12");
    showFather(topvue,"notice13");
	showNoticeELements(topvue, "notice12", "1", "i");
	showNoticeELements(topvue, "notice13", "1", "i");
}
/**
 * 控制小于12岁问题 是否显示
 * @param topvue
 */
function checkinfantNotice(topvue) {
	var formdata = topvue.formdata;
	if (formdata['lcinsured'] 
			&& formdata['lcinsured'].lcinsuredage
			&& formdata['lcinsured'].lcinsuredage <= 12) {
		showAllinfant(topvue);
	}else{
		hiddenAllinfant(topvue);
		
	}
}


/***
 * 女性被保人告知显示
 * @param topvue
 * @returns {Boolean}
 */
function showELementSByInsu(topvue) {
    try{

        var formdata = topvue.formdata;
        // var lcappntsex = formdata['lcappnt'].appntsex;
        var lcinsuredsex = formdata['lcinsured'].lcinsuredsex;
        if(lcinsuredsex=='1'){
            showFather(topvue,"notice17");
            showNoticeELements(topvue, "notice17", "1", "q");
        }
        else {
        	hiddenFather(topvue,"notice17");
        	hiddenNoticeELements(topvue, "notice17", "1", "q");
		}

    } catch (e) {
        // TODO: handle exception
    }

    return true;
}

///***
// * 被保险人/投保人情况告知（年金类产品）
// * @param topvue
// * @returns {Boolean}
// */
//function showELementInsu(topvue) {
//    try{
//        var formdata = topvue.formdata;
//        var conttype = formdata['lcpol'].conttype;
//        if(conttype=='10'){
//            showFather(topvue,"notice28");
//            showNoticeELements(topvue, "notice28", "1", "q");
//            showNoticeELements(topvue, "notice28", "2", "q");
//            showNoticeELements(topvue, "notice28", "3", "q");
//            showNoticeELements(topvue, "notice28", "1", "i");
//        	showNoticeELements(topvue, "notice28", "1", "a");
//        	showFather(topvue,"notice29");
//            showNoticeELements(topvue, "notice29", "1", "i");
//        	showNoticeELements(topvue, "notice29", "1", "a");
//        }
//        else {
//        	hiddenFather(topvue,"notice28");
//        	hiddenNoticeELements(topvue, "notice28", "1", "q");
//        	hiddenNoticeELements(topvue, "notice28", "2", "q");
//        	hiddenNoticeELements(topvue, "notice28", "3", "q");
//        	hiddenNoticeELements(topvue, "notice28", "1", "i");
//        	hiddenNoticeELements(topvue, "notice28", "2", "a");
//        	hiddenFather(topvue,"notice29");
//        	hiddenNoticeELements(topvue, "notice29", "1", "i");
//        	hiddenNoticeELements(topvue, "notice29", "2", "a");
//		}
//
//    } catch (e) {
//        // TODO: handle exception
//    }
//
//    return true;
//}
afterloadNewElements.lcbnf_tabinfo = function(url, form_element) {
	
	try {
		var topvue = getTopvueObj(this);
		showBelongInsu(topvue);
	} catch (e) {
		
		console.info("afterloadNewElements.lcbnf_tabinfo : " + e);
	}
	
};

afterloadNewElements.subriskcode_tabinfo = function(url, form_element) {
	
	try {
		var topvue = getTopvueObj(this);
		showBelongInsu(topvue);
	} catch (e) {
		console.info("afterloadNewElements.subriskcode_tabinfo : " + e);
	}
	
};


// 告知加载后的处理
afterloadNewElements.notice_tabinfo = function(url, form_element) {
	console.info( " 告知加载后的处理");
	var topvue = getTopvueObj(this);
	// checksimpleNotice(topvue);//之前处理未成年人的
	checkinfantNotice(topvue);//对于小于12岁的处理
	showELementSByInsu(topvue);//这边处理女性告知
//	showELementInsu(topvue);//被保险人/投保人情况告知（年金类产品）
	var showElement= 0 ;
	for ( var index in topvue.form_elements.commonFormNotice) {
		if(topvue.form_elements.commonFormNotice[index].elementstatus=='01'){
			showElement++;
		}
		
	}
	
	if(showElement==0){
		
		$("#notice_submit").trigger("click");
	}else{
		$("#tab_notice_tabinfo").removeClass("disabled");
		$("#notice_tabinfo").removeClass("disabled");
		
	}
	
    var timer=setInterval(function(){
    	if($("#notice_tabinfoform  .col-sm-12:eq(0)").is(":visible")){
    		//更改Facat样式
    		var text=$("span:contains(本人持有美国护照或美国绿卡)").text();
    		var texts=text.split(".");
    		var result="";
    		for(var i=0;i<texts.length;i++){
    			if(i==0)
    				result+="<strong>"+texts[i]+"</strong>"+"<hr/>";
    			else
    			    result+="<p>"+texts[i]+"</p>";
    		}
    		$("span:contains(本人持有美国护照或美国绿卡)").html(result);
    		//加上信息框1
    		var text2=$("span:contains(过去或现在是否患有下列“注一”之疾病)").text();
    		var texts2=text2.split("注一")
    		var result2=texts2[0]+"<span class='label label-important' style='cursor:help;color:blue'"+ 
    		"title='注一内容' data-container='body' data-toggle='popover_meli' "+
    		"data-content='高血压病（收缩压>=140，舒张压>=90）、冠心病（包括心绞痛，心肌梗塞，冠状动脉手术或支架等）、心肌病变、心内膜炎、风湿性心脏病、先天性心脏病、主动脉血管瘤、心律失常、心脏瓣膜疾病（狭窄、闭锁不全、畸形）、短暂性脑缺血、脑中风、脑瘤、脑动脉血管瘤、癫痫、脑积水、脑炎、脑膜炎、老年痴呆症（阿尔茨海默病）、惊厥、抽搐、肌肉萎缩、重症肌无力、多发性硬化症、运动神经元疾病（如进行性肌萎缩、肌萎缩性侧索硬化）、进行性球麻痹、震颤麻痹（帕金森氏）综合征、智能障碍、精神疾病、肺气肿、哮喘、支气管扩张症、尘肺、肺结核、肺栓塞、肝炎（除甲型、戊型）、肝硬化、肝功能异常、肝脾肿大、溃疡性结肠炎、克隆病、肾炎、肾病综合征、肾功能异常、尿毒症、视网膜出血或剥离、视神经病变、癌症、血友病、白血病、再生障碍性贫血、紫癜、糖尿病、类风湿性关节炎、肢端肥大症、垂体机能亢进或减退、血糖升高，多囊肝，多囊肾，近3个月新发现的淋巴结肿大、甲状腺或甲状旁腺机能亢进或减退、硬皮病、红斑狼疮、混合结缔组织病、系统性硬化病、艾滋病或艾滋病毒携带，颈部甲状腺、乳腺或者身体其他部位的肿块、结节、新生物、赘生物等，或者体检、检查结果显示或您自检发现前述部位存在异常，未经证实为良性或恶性之肿瘤。 (Note 1): hypertension; coronary heart disease (including angina pectoris, myocardial infarction, coronary artery surgery or stents, etc.); myocardial disease; endocarditis; rheumatic heart disease; congenital heart disease; aorta hemangioma; arrhythmia; heart valve disorders(stenosis, insufficiency, abnormality); transient cerebral ischemia; cerebral apoplexy; brain tumor; cerebral arterial hemangioma; epilepsy; hydrocephalus; encephalitis; meningitis; senile dementia (Alzheimer’s disease); convulsion; twitch; muscular atrophy; multiple sclerosis; motor neuron disease(e.g. progressive muscular atrophy, amyotrophic lateral sclerosis); progressive bulbar paralysis; Parkinson’s disease; intellectual impairment; mental disorder; emphysema; asthma; bronchiectasis; pneumoconiosis; pulmonary tuberculosis; pulmonary embolism; hepatitis (except hepatitis A, hepatitis E); cirrhosis; hepatic dysfunction; hepatosplenomegaly; ulcerative colitis; Crohn’s disease; nephritis; nephrotic syndrome; kidney dysfunction; uremia; retinal hemorrhage or detachment; optic nerve disease; cancer; hemophilia; leukemia; aplastic anemia; purpura; diabetes mellitus; rheumatoid arthritis; acromegaly; hyperpituitarism or hypopituitarism; hyperglycosemia; polycystic liver; polycystic kidney, lymph enlargement in past 3 months; hyperthyroidism or hypothyroidism; hyperparathyroidism or hypoparathyroidism; scirrhosarca; systematic lupus erythematosus; mixed connective tissue disease; systemic sclerosis; AIDS or HIV carrier; nodule, lump, neoplasm etc. of thyroid glands, breast, or other parts of the body; physical exam or other examination or self check shows abnormality of above mentioned parts of the body, un-identified tumor.'>注一</span>"+texts2[1];
    		$("span:contains(过去或现在是否患有下列“注一”之疾病)").html(result2);
    		//加上信息框1
    		var text3=$("span:contains(过去二年内是否患有下列“注二”之疾病或症状？)").text();
    		var texts3=text3.split("注二")
    		var result3=texts3[0]+"<span class='label label-important' style='cursor:help;color:blue'"+ 
    		"title='注二内容' data-container='body' data-toggle='popover_meli' "+
    		"data-content='酒精或药物滥用成瘾、脊髓灰质炎、眩晕症，食道、胃、十二指肠溃疡或出血或穿孔，胰腺炎、肝炎病毒携带、脂肪肝、肝脓肿、肝血管瘤、肝内结石、疝、慢性阑尾炎、痔疮或肛周疾病、痛风、慢性支气管炎、肺脓肿、青光眼、白内障、心肌炎、脑膜炎、梅尼尔氏症、呼吸暂停综合征，中耳炎、鼻窦炎、鼻中隔弯曲、慢性扁桃体炎、肺炎、胸膜炎、气胸、胆结石、胆囊炎、息肉、便血、泌尿系统结石或炎症、蛋白尿（泡沫尿）、血尿、肾囊肿、盆腔炎、前列腺肥大、前列腺炎、性病、关节炎、椎间盘突出、坐骨神经痛、蚕豆病、贫血、静脉曲张、良性肿瘤（以下请女性被保险人回答）乳房疾病、子宫内膜异位症、阴道异常出血、子宫肌瘤、宫颈疾病，妊娠并发症、习惯性流产或其他生殖系统疾病或妇科检查异常、怀孕，(Note 2): alcohol or drug abuse; poliomyelitis; vertigo; esophageal, gastric or duodenal ulcer, bleeding or perforation; pancreatitis; hepatitis virus infection; fatty liver; hepatapostema; hepatic hemangioma; intrahepatic stone; hernia; chronic appendicitis; hemorrhoid or anal diseases; gout; chronic bronchitis; lung abscess; glaucoma; cataract; myocarditis; meningitis; meniere’s syndrome; sleep apnea; otitis media; nasosinusitis; deviation of nasal septum; chronic tonsillitis; pneumonia; pleurisy; pneumothorax; gallstones; cholecystitis; polyp; hematochezia; urolithiasis or urinary system inflammation; proteinuria; hematuria; renal cyst; pelvic inflammatory disease; prostatic hypertrophy; prostatitis; STDs; arthritis; protrusion of intervertebral disc; sciatica; favism; anemia; varicosity; benign tumor; (for female insured, please answer the following questions) breast disease; endometriosis; colporrhagia; hysteromyoma; cervical disease; pregnancy complications; habitual abortion, or other reproductive system disease, or gynecologic exam anomaly;pregnancy;'>注二</span>"+texts3[1];
    		$("span:contains(过去二年内是否患有下列“注二”之疾病或症状？)").html(result3);
    		$("[data-toggle='popover_meli']").popover({trigger:'hover'});
    		checkY();
    		//前端校验疾病
    		$("input:radio").click(function(){
    			//noticeinfos[].insuredyesorno  noticeinfos[].owneryesorno
    			//重置验证
    			if($("#notice_tabinfoform").data('bootstrapValidator')!=null&&
    					$("#notice_tabinfoform").data('bootstrapValidator')!=undefined){
	    			console.info("重置验证");
	    			var form =$("#notice_tabinfoform");
	    	    	form.data('bootstrapValidator').resetField($('#notice18q117'));
	    			form.data('bootstrapValidator').resetField($('#notice18q217'));
	    	    	form.data('bootstrapValidator').resetField($('#notice18q317'));
	    			form.data('bootstrapValidator').resetField($('#notice18q417'));
	//    			form.data('bootstrapValidator').resetField($(input[type="radio"]));
    			}
    			checkY();
			});	
    		clearInterval(timer);
    	}	
    },100);
};


//告知提交前 清空所有不显示的数据
beforesubmitvueform.notice_tabinfoform = function() {
//	v-bind:elementstatus ="form_element.elementstatus"
	$("#notice_tabinfoform").find("[elementstatus][elementstatus!='01']").val('').trigger("click");
//	if($("#notice_tabinfoform").find("[elementstatus][elementstatus!='01']").length==0){
//		
//		
////		this.$set(this.formdata.newContApply,"currentSIDIndex",7);
//		
//		this.$set(this.formdata.newContApply,"currentSID", "contsubmit_tabinfo");
////		this.$set(this.formdata.newContApply,"currentSIDIndex",8);
////		$("#tab_notice_tabinfo").removeClass("active");
////		$("#tab_notice_tabinfo").addClass("disabled");
////		$("#notice_tabinfo").removeClass("active");
////		$("#notice_tabinfo").addClass("disabled");
////		$("#tab_contsubmit_tabinfo").addClass("active");
////		$("#contsubmit_tabinfo").addClass("active");
//	}else{
		 
		
//	}
//if($("#notice_tabinfoform").find("[elementstatus][elementstatus='01']").length==0){
//		
//		
//		this.$set(this.formdata.newContApply,"currentSID", "contsubmit");
//		this.$set(this.formdata.newContApply,"currentSIDIndex",8);
// con
//	}else{
//		 
//		
//	}
	return true; 
};

aftersubmitvueform.notice_tabinfoform = function() {
	 
	if($("#notice_tabinfoform").find("[name^='noticeinfo'][elementstatus][elementstatus='01']").length==0){
		
		this.$set(this.formdata.newContApply,"currentSID", "contsubmit");
		this.$set(this.formdata.newContApply,"currentSIDIndex",8);
		this.$set(this.formdata.newContApply,"contsubmit", false);
		$('#tab_contsubmit_tabinfo').trigger("click");
		this.$set(this.form_elementsBYID.MELIinsuranceContInput['notice_tabinfo'],
				"elementstatus", "04");
		
		
	}else{
		 
		
	}
	try {
		var proposalcontno=vueobj["testdivchange"].formdata.lccont.proposalcontno;
		buttonControl(proposalcontno);
	} catch (e) {

	}
	return true; 
};

/*  	$("#notice_tabinfoform").click(function(){
		alert("b");
	});  */	
/* 	alert($("#notice_tabinfoform  .col-sm-12:eq(18)").length); */
    
    
    function checkY() {
    	var hasY=false;
		for(var i=8;i<10;i++){
			if("Y"==($("input[name='noticeinfos["+i+"].owneryesorno']:checked").val())||"Y"==($("input[name='noticeinfos["+i+"].insuredyesorno']:checked").val())){
				hasY=true;
				break;
			}
			hasY=false;
		}
		if(!hasY){
			$("#notice18q117").attr("disabled","disabled");    
			$("#notice18q217").attr("disabled","disabled");
			$("#notice18q317").attr("disabled","disabled");
			$("#notice18q417").attr("disabled","disabled");
		}
		else {
			$("#notice18q117").removeAttr("disabled");    
			$("#notice18q217").removeAttr("disabled");
			$("#notice18q317").removeAttr("disabled");
			$("#notice18q417").removeAttr("disabled");
		}
	}